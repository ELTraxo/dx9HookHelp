#pragma once

struct iPosDim
{
	int x, y, w, h;
};

class Draw
{
public:
	static void FilledRect(LPDIRECT3DDEVICE9 pDevice, int x, int y, int w, int h, D3DCOLOR color)
	{
		D3DRECT rect = { x, y, x + w, y + h };
		pDevice->Clear(1, &rect, D3DCLEAR_TARGET, color, 0.0f, 0);
	}

	static void CreateFont(LPDIRECT3DDEVICE9 pDevice, int iFontSize, LPD3DXFONT & pFont)
	{
		D3DXCreateFont(pDevice, iFontSize, 0, FW_BOLD, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &pFont);
	}

	static void DrawText(LPDIRECT3DDEVICE9 pDevice, LPD3DXFONT & pFont, int iFontSize, int x, int y, D3DCOLOR color, const TCHAR * text)
	{
		if (!pFont)
			CreateFont(pDevice, iFontSize, pFont);
		RECT rect;
		SetRect(&rect, x, y, x, y);
		pFont->DrawText(NULL, text, -1, &rect, DT_NOCLIP | DT_LEFT, color);
	}
};